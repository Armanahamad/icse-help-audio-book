const OWNER_PASSWORD = "yourpassword123"; // Change this to your password

function checkPassword() {
  const password = document.getElementById("passwordInput").value;
  if (password === OWNER_PASSWORD) {
    document.getElementById("loginDiv").style.display = "none";
    document.getElementById("uploadSection").style.display = "block";
  } else {
    alert("Incorrect password!");
  }
}

function uploadAudio() {
  const title = document.getElementById("audioTitle").value;
  const fileInput = document.getElementById("audioFile");
  const file = fileInput.files[0];

  if (!title || !file) {
    alert("Please enter a title and select an audio file.");
    return;
  }

  const reader = new FileReader();
  reader.onload = function (e) {
    const audioList = document.getElementById("audioList");

    const audioItem = document.createElement("div");
    audioItem.className = "audio-item";

    const titleElement = document.createElement("h3");
    titleElement.textContent = title;

    const audioElement = document.createElement("audio");
    audioElement.controls = true;
    audioElement.src = e.target.result;

    audioItem.appendChild(titleElement);
    audioItem.appendChild(audioElement);
    audioList.prepend(audioItem);

    document.getElementById("audioTitle").value = "";
    document.getElementById("audioFile").value = "";
  };

  reader.readAsDataURL(file);
}
